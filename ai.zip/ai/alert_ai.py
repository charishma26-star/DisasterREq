# alert_ai.py - simple AI module for smart alerts
from collections import deque
import statistics

device_history = {}
MAX_HISTORY = 5  # last 5 readings

def check_alert(sensor):
    device = sensor["deviceId"]
    value = float(sensor["value"])

    if device not in device_history:
        device_history[device] = deque(maxlen=MAX_HISTORY)
    
    history = device_history[device]
    history.append(value)

    if len(history) < 3:
        return False

    mean = statistics.mean(history)
    stdev = statistics.stdev(history)

    if value > 7 or value > mean + 1.5*stdev:
        return True
    return False
