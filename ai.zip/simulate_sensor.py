import requests
import random
import time
import datetime

url = "http://127.0.0.1:5000/api/sensor"

while True:
    data = {
        "deviceId": "device_001",
        "type": random.choice(["temperature", "smoke", "water"]),
        "value": random.randint(10, 100),
        "lat": 12.9716,   # Example coordinates
        "lon": 77.5946,
        "ts": str(datetime.datetime.utcnow())
    }
    try:
        response = requests.post(url, json=data)
        print("Sent:", data)
        print("Response:", response.json())
    except Exception as e:
        print("Error:", e)
    time.sleep(5)
