import hashlib
import json
import time
import uuid
from datetime import datetime, timedelta

class ProofOfHistory:
    """Core PoH implementation - creates verifiable hash sequences"""
    
    def __init__(self):
        self.sequence = []
        self.current_hash = self._generate_initial_hash()
        self.tick_count = 0
    
    def _generate_initial_hash(self):
        """Generate initial hash for the PoH sequence"""
        data = str(time.time()) + str(uuid.uuid4())
        return hashlib.sha256(data.encode()).hexdigest()
    
    def tick(self, data=''):
        """Core PoH: Generate next hash in sequence"""
        input_string = f"{self.current_hash}{data}{self.tick_count}"
        new_hash = hashlib.sha256(input_string.encode()).hexdigest()
        
        entry = {
            'index': self.tick_count,
            'hash': new_hash,
            'previous_hash': self.current_hash,
            'timestamp': time.time(),
            'data': data
        }
        
        self.sequence.append(entry)
        self.current_hash = new_hash
        self.tick_count += 1
        
        return entry
    
    def verify_sequence(self, sequence):
        """Verify PoH sequence integrity"""
        if not sequence or len(sequence) == 0:
            return False
        
        for i, entry in enumerate(sequence):
            # Verify hash chain
            if i > 0:
                if entry['previous_hash'] != sequence[i - 1]['hash']:
                    return False
            
            # Verify hash computation
            input_string = f"{entry['previous_hash']}{entry['data']}{entry['index']}"
            computed_hash = hashlib.sha256(input_string.encode()).hexdigest()
            
            if computed_hash != entry['hash']:
                return False
        
        return True
    
    def get_current_state(self):
        """Get current PoH state"""
        return {
            'current_hash': self.current_hash,
            'tick_count': self.tick_count,
            'last_entry': self.sequence[-1] if self.sequence else None
        }
    
    def create_user_challenge(self, user_id):
        """Create a user-specific PoH challenge for authentication"""
        challenge = self.tick(f"USER_CHALLENGE:{user_id}")
        return {
            'user_id': user_id,
            'challenge_hash': challenge['hash'],
            'timestamp': challenge['timestamp'],
            'index': challenge['index']
        }
    
    def verify_user_challenge(self, user_id, challenge_hash, response_hash, timestamp):
        """Verify user challenge response"""
        # Check if response is within valid time window (5 minutes)
        current_time = time.time()
        time_window = 5 * 60  # 5 minutes in seconds
        
        if current_time - timestamp > time_window:
            return {'valid': False, 'reason': 'Challenge expired'}
        
        # Verify the response hash is correctly derived
        expected_response = hashlib.sha256(
            f"{challenge_hash}{user_id}".encode()
        ).hexdigest()
        
        if response_hash != expected_response:
            return {'valid': False, 'reason': 'Invalid response hash'}
        
        return {'valid': True, 'reason': 'Challenge verified'}


class UserPoHManager:
    """Manages individual user PoH sequences for authentication"""
    
    def __init__(self):
        self.user_sequences = {}
        self.global_poh = ProofOfHistory()
        self.active_challenges = {}
    
    def register_user(self, user_id, user_info):
        """Register new user with PoH sequence"""
        if user_id in self.user_sequences:
            return {'success': False, 'message': 'User already exists'}
        
        user_poh = ProofOfHistory()
        registration_entry = user_poh.tick(
            f"REGISTER:{user_id}:{json.dumps(user_info)}"
        )
        
        # Hash the password with PoH
        password_hash = hashlib.sha256(
            f"{user_info['password']}{registration_entry['hash']}".encode()
        ).hexdigest()
        
        self.user_sequences[user_id] = {
            'poh': user_poh,
            'registration_hash': registration_entry['hash'],
            'registration_time': registration_entry['timestamp'],
            'user_info': {
                'username': user_info['username'],
                'role': user_info.get('role', 'user'),
                'email': user_info.get('email', '')
            },
            'password_hash': password_hash,
            'login_attempts': []
        }
        
        # Record in global PoH
        self.global_poh.tick(f"USER_REGISTERED:{user_id}")
        
        return {
            'success': True,
            'message': 'User registered successfully',
            'registration_hash': registration_entry['hash']
        }
    
    def create_login_challenge(self, user_id, password):
        """Create login challenge for user"""
        if user_id not in self.user_sequences:
            return {'success': False, 'message': 'User not found'}
        
        user_data = self.user_sequences[user_id]
        
        # Verify password first
        temp_hash = hashlib.sha256(
            f"{password}{user_data['registration_hash']}".encode()
        ).hexdigest()
        
        if temp_hash != user_data['password_hash']:
            return {'success': False, 'message': 'Invalid credentials'}
        
        # Create challenge
        challenge = user_data['poh'].create_user_challenge(user_id)
        challenge_id = str(uuid.uuid4())
        
        # Store challenge
        self.active_challenges[challenge_id] = {
            'user_id': user_id,
            'challenge_hash': challenge['challenge_hash'],
            'timestamp': challenge['timestamp'],
            'verified': False
        }
        
        # Calculate response hash for client
        response_hash = hashlib.sha256(
            f"{challenge['challenge_hash']}{user_id}".encode()
        ).hexdigest()
        
        return {
            'success': True,
            'challenge_id': challenge_id,
            'challenge_hash': challenge['challenge_hash'],
            'response_hash': response_hash,
            'timestamp': challenge['timestamp']
        }
    
    def verify_login(self, challenge_id, response_hash):
        """Verify login attempt using challenge response"""
        if challenge_id not in self.active_challenges:
            return {'success': False, 'message': 'Invalid or expired challenge'}
        
        challenge = self.active_challenges[challenge_id]
        
        if challenge['verified']:
            return {'success': False, 'message': 'Challenge already used'}
        
        user_id = challenge['user_id']
        user_data = self.user_sequences[user_id]
        
        # Verify the challenge
        verification = user_data['poh'].verify_user_challenge(
            user_id,
            challenge['challenge_hash'],
            response_hash,
            challenge['timestamp']
        )
        
        if verification['valid']:
            challenge['verified'] = True
            
            # Add login event to user's PoH
            login_entry = user_data['poh'].tick(f"LOGIN:{user_id}:{time.time()}")
            
            # Record in global PoH
            self.global_poh.tick(f"USER_LOGIN:{user_id}")
            
            # Generate session token
            session_token = self._generate_session_token(user_id, login_entry['hash'])
            
            return {
                'success': True,
                'message': 'Login verified',
                'session_token': session_token,
                'user_info': user_data['user_info'],
                'login_hash': login_entry['hash']
            }
        
        return {'success': False, 'message': verification['reason']}
    
    def _generate_session_token(self, user_id, login_hash):
        """Generate session token"""
        token_data = f"{user_id}:{login_hash}:{time.time()}:{uuid.uuid4()}"
        return hashlib.sha256(token_data.encode()).hexdigest()
    
    def verify_session_token(self, user_id, token):
        """Verify session token (simplified version)"""
        if user_id not in self.user_sequences:
            return False
        
        # In production, you'd store tokens with expiration
        # This is a simplified check
        return token and len(token) == 64  # SHA256 length check
    
    def get_user_sequence(self, user_id):
        """Get user's PoH sequence for verification"""
        if user_id not in self.user_sequences:
            return None
        
        user_data = self.user_sequences[user_id]
        return {
            'sequence': user_data['poh'].sequence,
            'registration_hash': user_data['registration_hash'],
            'registration_time': user_data['registration_time']
        }
    
    def get_user_info(self, user_id):
        """Get user information"""
        if user_id not in self.user_sequences:
            return None
        
        return self.user_sequences[user_id]['user_info']


# Global instance for the application
poh_manager = UserPoHManager()
