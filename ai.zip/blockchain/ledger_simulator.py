import json, uuid, datetime, os

LEDGER_FILE = os.path.join(os.path.dirname(__file__), "ledger.json")

def read_ledger():
    if not os.path.exists(LEDGER_FILE):
        return []
    with open(LEDGER_FILE, "r") as f:
        return json.load(f)

def write_ledger(data):
    with open(LEDGER_FILE, "w") as f:
        json.dump(data, f, indent=4)

def add_transaction(alert):
    ledger = read_ledger()
    tx = {
        "txId": str(uuid.uuid4()),
        "timestamp": str(datetime.datetime.utcnow()),
        "alertId": alert["id"],
        "type": alert["type"],
        "location": alert["source"].get("lat"),
        "value": alert["source"].get("value"),
        "status": alert["status"]
    }
    ledger.append(tx)
    write_ledger(ledger)
    print(f"[BLOCKCHAIN] Transaction added: {tx['txId']}")
    return tx

def get_transactions():
    return read_ledger()
