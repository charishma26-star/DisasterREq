from flask import Flask, request, jsonify
import json, uuid, datetime, os
from ai.alert_ai import check_alert               # 🔹 AI module
from blockchain.ledger_simulator import add_transaction  # 🔹 Blockchain ledger
from flask_cors import CORS                        # 🔹 CORS

app = Flask(__name__)
CORS(app)  # 🔹 Allow browser requests from any origin

# ---------- Utility Functions ----------
DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
os.makedirs(DATA_DIR, exist_ok=True)

def read_json(filename):
    path = os.path.join(DATA_DIR, filename)
    if not os.path.exists(path):
        return []
    with open(path, "r") as f:
        return json.load(f)

def write_json(filename, data):
    path = os.path.join(DATA_DIR, filename)
    with open(path, "w") as f:
        json.dump(data, f, indent=4)

# ---------- Routes ----------
@app.route("/")
def home():
    return jsonify({"message": "DisasterResQ Backend Running", "status": "ok"})

# ---------- IoT Sensor Endpoint ----------
@app.route("/api/sensor", methods=["POST"])
def sensor():
    payload = request.get_json() or {}
    print("Received sensor data:", payload)

    sensors = read_json("sensors.json")
    entry = {
        "id": str(uuid.uuid4()),
        "deviceId": payload.get("deviceId"),
        "type": payload.get("type"),
        "value": payload.get("value"),
        "lat": payload.get("lat"),
        "lon": payload.get("lon"),
        "ts": payload.get("ts") or str(datetime.datetime.utcnow())
    }

    sensors.append(entry)
    write_json("sensors.json", sensors)

    # ---------- AI Alert Detection ----------
    alerts = read_json("alerts.json")
    if check_alert(entry):
        alert_entry = {
            "id": str(uuid.uuid4()),
            "type": "flood",
            "source": entry,
            "createdAt": str(datetime.datetime.utcnow()),
            "status": "new"
        }
        alerts.append(alert_entry)
        write_json("alerts.json", alerts)
        print("⚠️ Alert triggered:", alert_entry)

        # ---------- Blockchain Ledger ----------
        add_transaction(alert_entry)

    return jsonify({"ok": True, "saved": entry})

# ---------- Get Alerts ----------
@app.route("/api/alerts", methods=["GET"])
def get_alerts():
    return jsonify(read_json("alerts.json"))

# ---------- Get Sensors (plural) ----------
@app.route("/api/sensors", methods=["GET"])
def get_sensors():
    return jsonify(read_json("sensors.json"))

# ---------- Get Blockchain Ledger ----------
@app.route("/api/ledger", methods=["GET"])
def get_ledger():
    from blockchain.ledger_simulator import get_transactions
    return jsonify(get_transactions())

# ---------- Run ----------
if __name__ == "__main__":
    app.run(debug=True)
